MAO trace pack
Verify with: python -m mao.pack verify this.zip
